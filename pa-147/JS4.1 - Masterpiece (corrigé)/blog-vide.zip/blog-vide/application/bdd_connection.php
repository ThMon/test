<?php

	$pdo = new PDO('mysql:host=localhost;dbname=blog2', 'root', 'troiswa');

	$pdo->exec('SET NAMES UTF8');


?>